<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students List</title>
</head>
<body>
    <h1>Students List</h1>
    <a href="<?= base_url('home/student/0'); ?>">Add Student</a>

    <table border=1>
        <tr>
            <th>Action</th>
            <th>No</th>
            <th>Roll No</th>
            <th>Name</th>
            <th>Mobile No</th>
        </tr>
        <?php
            $count = 1;
            foreach($students as $student)
            {
        ?>
            <tr>
                <td>
                    <a href="<?= base_url("home/student/" . $student->id); ?>">Edit</a>
                    <a href="<?= base_url("home/deletestudent/" . $student->id); ?>" onclick="return confirm('Sure to delete?')">Delete</a>
                </td>
                <td><?= $count; ?></td>
                <td><?= $student->rollno; ?></td>
                <td><?= $student->name; ?></td>
                <td><?= $student->mobileno; ?></td>
            </tr>
        <?php
            $count++;
            }
        ?>
    </table>
</body>
</html>