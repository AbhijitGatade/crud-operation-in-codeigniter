<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student</title>
</head>
<body>
    <form method="POST" action="<?= base_url("home/savestudent"); ?>">
        <input type="hidden" id="id" name="id" value="<?= $id; ?>" />
        <input type="number" id="rollno" name="rollno" placeholder="Enter Roll No" value="<?= $id == 0 ? "" : $student->rollno; ?>" required />
        <input type="text" id="name" name="name" placeholder="Enter Name" value="<?= $id == 0 ? "" : $student->name; ?>" required />
        <input type="number" id="mobileno" name="mobileno" placeholder="Enter Mobile No" value="<?= $id == 0 ? "" : $student->mobileno; ?>" required />
        <input type="submit" value="Save" />
    </form>
</body>
</html>